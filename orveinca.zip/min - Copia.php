<?php
include ("clases/myapp.php");
define('__DOCUMENT_ROOT__','/orveinca');
MyApp::Start();