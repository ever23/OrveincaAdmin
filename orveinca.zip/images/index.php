<?php
include("../clases/config_orveinca.php");
header("Location: ".__AUTORIZATE_DIRNAME__."index.php");	
exit();
