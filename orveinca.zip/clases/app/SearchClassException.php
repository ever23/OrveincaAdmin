<?php
require_once('sysexeption.php');
class SearchClassException extends SysExeption{} 
