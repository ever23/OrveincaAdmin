<?php
define('HOST','127.0.0.1');
define('USER','root');
define('PASS','ever2310');
define('DB','orveinca2');
define('__LLAVEMD5__',"@$#=?¡%&");
define('__AUTORIZATE_DIRNAME__',"http://localhost/orveinca/");
define('__AUTORIZATE_ROOT__',8247);
define('__AUTORIZATE_ADMIN__',6454);
define('__AUTORIZATE_VEND__','');

?>